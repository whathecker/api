module.exports = {
    verbose: true,
    testEnvironment: 'node'
}