const router = require('express').Router();

router.use('/', require('./api'));

module.exports = router;